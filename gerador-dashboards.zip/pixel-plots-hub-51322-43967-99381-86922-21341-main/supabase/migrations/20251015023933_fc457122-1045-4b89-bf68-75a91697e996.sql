-- Create executive_reports table for saved reports
CREATE TABLE public.executive_reports (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID REFERENCES public.organizations(id) ON DELETE CASCADE NOT NULL,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  dataset_id UUID REFERENCES public.datasets(id) ON DELETE CASCADE NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  report_data JSONB NOT NULL,
  report_type TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now() NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT now() NOT NULL
);

-- Enable RLS
ALTER TABLE public.executive_reports ENABLE ROW LEVEL SECURITY;

-- RLS Policies for executive_reports
CREATE POLICY "C-level and admins can view all reports in their organization"
  ON public.executive_reports FOR SELECT
  TO authenticated
  USING (
    organization_id = public.get_user_organization(auth.uid()) AND
    (public.has_role(auth.uid(), 'c_level') OR public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'owner'))
  );

CREATE POLICY "C-level can create reports"
  ON public.executive_reports FOR INSERT
  TO authenticated
  WITH CHECK (
    organization_id = public.get_user_organization(auth.uid()) AND
    user_id = auth.uid() AND
    (public.has_role(auth.uid(), 'c_level') OR public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'owner'))
  );

CREATE POLICY "Users can update their own reports"
  ON public.executive_reports FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "C-level and admins can delete reports"
  ON public.executive_reports FOR DELETE
  TO authenticated
  USING (
    organization_id = public.get_user_organization(auth.uid()) AND
    (public.has_role(auth.uid(), 'c_level') OR public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'owner'))
  );

-- Create trigger for updated_at
CREATE TRIGGER set_updated_at
  BEFORE UPDATE ON public.executive_reports
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_updated_at();