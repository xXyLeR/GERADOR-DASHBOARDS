-- Force types regeneration
COMMENT ON TABLE public.datasets IS 'Stores uploaded datasets for analysis';