-- Add c_level to the role enum (this needs to be in a separate transaction)
ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'c_level';