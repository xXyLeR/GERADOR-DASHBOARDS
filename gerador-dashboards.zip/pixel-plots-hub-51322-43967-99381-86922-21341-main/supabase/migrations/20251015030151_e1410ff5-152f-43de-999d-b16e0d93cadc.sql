-- Força regeneração dos tipos do Supabase
-- Adiciona comentários às tabelas para forçar atualização dos tipos

COMMENT ON TABLE public.profiles IS 'User profiles with organization membership';
COMMENT ON TABLE public.datasets IS 'Datasets uploaded by users for analysis';
COMMENT ON TABLE public.user_roles IS 'User role assignments';
COMMENT ON TABLE public.organizations IS 'Organizations that users belong to';
COMMENT ON TABLE public.executive_reports IS 'Executive reports generated from datasets';
COMMENT ON TABLE public.analysis_history IS 'History of analysis performed on datasets';